class Buttons {

  constructor(xpos, y, diameter, _speed) {

    this.isPressed = false;
    this.xpos = xpos;
    this.y = y;
    this.diameter = diameter;

    this.c_motion_xpos = xpos;
    this.c_motion_y = y;
    this.c_motion_diameter = diameter;
    this._speed = _speed;
    this.gotColor = false;
    
    this.pixelColor = color(51,51,51);

    
  }

  button() {
    noFill();
    //noStroke();

    let distance = dist(mouseX, mouseY, this.xpos, this.y);

    this.radius = this.diameter / 2;

    if (mouseIsPressed) {
      if (distance < this.radius) {
        //fill(193, 75, 136);
        this.isPressed = true;
      }

    }

    circle(this.xpos, this.y, this.diameter);

  }

  blackCircle(xpos, y, diameter) {
    if (this.isPressed) {
      fill(51);
      circle(this.xpos, this.y, this.diameter);
    }
  }

  move(xpos, y, diameter) {
    
    if (this.isPressed) {
      
      if(this.gotColor == false){
        
        this.pixelColor = get(mouseX,mouseY);
        
        this.gotColor = true;
      }
      
      if (this.c_motion_y < height - 10) {
        
        this._speed = this._speed++;
        this.c_motion_y += this._speed;
      }
      
      fill(this.pixelColor);
      
      ellipse(this.c_motion_xpos, this.c_motion_y, this.c_motion_diameter, this.c_motion_diameter);
    }
 
  }

}