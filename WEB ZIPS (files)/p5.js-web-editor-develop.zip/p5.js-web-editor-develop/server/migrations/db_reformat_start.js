require('@babel/register');
require('regenerator-runtime/runtime');
require('./db_reformat');
