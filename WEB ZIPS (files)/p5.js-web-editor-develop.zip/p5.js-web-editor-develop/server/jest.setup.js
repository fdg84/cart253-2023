import 'regenerator-runtime/runtime';
import mongoose from 'mongoose';

mongoose.Promise = global.Promise;
