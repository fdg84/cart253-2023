// Need a stable, non-random name for testing

export function generateProjectName() {
  return 'Test project name';
}

export function generateCollectionName() {
  return `My test collection`;
}
