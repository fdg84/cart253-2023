// eslint-disable-next-line import/no-extraneous-dependencies
import 'jest-styled-components';
import 'regenerator-runtime/runtime';

// See: https://github.com/testing-library/jest-dom
// eslint-disable-next-line import/no-extraneous-dependencies
import '@testing-library/jest-dom';
