import AssetSize from './AssetSize';

export default {
  title: 'IDE/AssetSize',
  component: AssetSize
};

export const Default = {
  args: {
    totalSize: 123
  }
};
