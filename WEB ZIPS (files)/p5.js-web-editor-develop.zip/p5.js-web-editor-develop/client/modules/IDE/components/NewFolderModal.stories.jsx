import NewFolderModal from './NewFolderModal';

export default {
  title: 'IDE/NewFolderModal',
  component: NewFolderModal
};

export const Default = {};
