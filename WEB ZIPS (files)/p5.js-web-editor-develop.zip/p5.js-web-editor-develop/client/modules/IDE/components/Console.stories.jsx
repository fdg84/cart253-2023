import Console from './Console';

export default {
  title: 'IDE/Console',
  component: Console
};

export const Default = {};
