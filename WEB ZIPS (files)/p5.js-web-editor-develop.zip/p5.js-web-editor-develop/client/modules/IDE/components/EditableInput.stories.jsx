import EditableInput from './EditableInput';

export default {
  title: 'IDE/EditableInput',
  component: EditableInput
};

export const Default = {
  args: {
    value: 'an@email.com',
    label: 'Example'
  }
};
