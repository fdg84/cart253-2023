import NewFileForm from './NewFileForm';

export default {
  title: 'IDE/NewFileForm',
  component: NewFileForm
};

export const Default = {};
