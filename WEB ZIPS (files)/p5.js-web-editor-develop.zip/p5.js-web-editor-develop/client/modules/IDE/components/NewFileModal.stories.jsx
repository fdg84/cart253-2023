import NewFileModal from './NewFileModal';

export default {
  title: 'IDE/NewFileModal',
  component: NewFileModal
};

export const Default = {};
