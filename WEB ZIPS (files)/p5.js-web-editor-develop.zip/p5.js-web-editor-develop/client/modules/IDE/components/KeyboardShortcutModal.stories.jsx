import KeyboardShortcutModal from './KeyboardShortcutModal';

export default {
  title: 'IDE/KeyboardShortcutModal',
  component: KeyboardShortcutModal
};

export const Default = {};
