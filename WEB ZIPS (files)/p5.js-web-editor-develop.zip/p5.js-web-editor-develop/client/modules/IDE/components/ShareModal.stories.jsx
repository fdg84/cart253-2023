import ShareModal from './ShareModal';

export default {
  title: 'IDE/ShareModal',
  component: ShareModal
};

export const Default = {};
