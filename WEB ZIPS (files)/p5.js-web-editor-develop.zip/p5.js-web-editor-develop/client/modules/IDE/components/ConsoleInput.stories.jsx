import ConsoleInput from './ConsoleInput';

export default {
  title: 'IDE/ConsoleInput',
  component: ConsoleInput
};

export const Default = {};
