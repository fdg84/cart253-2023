import NewFolderForm from './NewFolderForm';

export default {
  title: 'IDE/NewFolderForm',
  component: NewFolderForm
};

export const Default = {};
