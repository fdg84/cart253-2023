import About from './About';

export default {
  title: 'IDE/About',
  component: About
};

export const Default = {};
