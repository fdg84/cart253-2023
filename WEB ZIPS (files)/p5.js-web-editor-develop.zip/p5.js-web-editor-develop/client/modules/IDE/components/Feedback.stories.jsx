import Feedback from './Feedback';

export default {
  title: 'IDE/Feedback',
  component: Feedback
};

export const Default = {};
