import FloatingActionButton from './FloatingActionButton';

export default {
  title: 'IDE/FloatingActionButton',
  component: FloatingActionButton
};

export const Default = {};
