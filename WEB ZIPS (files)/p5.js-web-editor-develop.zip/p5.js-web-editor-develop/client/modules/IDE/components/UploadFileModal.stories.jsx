import UploadFileModal from './UploadFileModal';

export default {
  title: 'IDE/UploadFileModal',
  component: UploadFileModal
};

export const Default = {};
