import CopyableInput from './CopyableInput';

export default {
  title: 'IDE/CopyableInput',
  component: CopyableInput
};

export const Default = {
  args: {
    value: 'Lorem Ipsum'
  }
};
