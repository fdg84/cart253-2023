import FileUploader from './FileUploader';

export default {
  title: 'IDE/FileUploader',
  component: FileUploader
};

export const Default = {};
