## mosaic-β

PDF : [mosaic-β](pdf/mosaic-beta.pdf)

PDF-JP : [mosaic-β japanese ver.](pdf/mosaic-beta-japanese.pdf)

I don't want to announce anything special, I just want to show the world how much I enjoy creative coding.

クリエイティブコーディングを通してモザイクを楽しんでいる様子を記しています.

![alt](assets/%20thumbnail/mosaic-beta-thumbnail.png)
