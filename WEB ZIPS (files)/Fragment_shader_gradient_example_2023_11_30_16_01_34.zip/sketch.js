let exampleShader;

// load in the shader
function preload() {
  exampleShader = loadShader('example.vert', 'example.frag');
}

function setup() {
  createCanvas(600, 600, WEBGL);
  shader(exampleShader);
}

function draw() {
  exampleShader.setUniform("millis", millis()); 
  // Run shader
  rect(-width/2, -height/2, width);
}