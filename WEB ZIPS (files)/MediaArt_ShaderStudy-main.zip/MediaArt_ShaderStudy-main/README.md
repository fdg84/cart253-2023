# MediaArt_ShaderStudy

shaderを学ぶリポジトリ。
以下サイトを参考に学ぶ

- https://wgld.org/
