// array of buttons
let buttonsArray = [];
let buttonsSound = [];
let osc = [];


//var osc;
var frequency = 250;

//for loop variables
let sizeButton = 40;
let startingPoint = 25;
let spacing = 50;



function setup() {
  createCanvas(400, 400);
  rectMode(CENTER);


  // Create an array of buttons objects to fill the screen
  // columns
  for (let columns = startingPoint; columns < height; columns += spacing) {
    // rows
    for (let row = startingPoint; row < width; row += spacing) {
      // parameters: x, y, size
      buttonsArray.push(new Buttons(row, columns, sizeButton));
      buttonsSound.push(new p5.Oscillator());
      // hacer un array de ocilators
      //osc + row = new p5.Oscillator();
      
    }
  }

  osc = new p5.Oscillator();
  osc.setType('sine');
  osc.freq(frequency);
  osc.amp(0);
  osc.start();
  console.log (buttonsSound);

}

function draw() {
  background(220);

  //Draw buttons to fill the screen
  for (let b of buttonsArray) {
    b.drawSquare();
    b.button();
    
    if (b.isPressed) {
      osc.amp(0.5, 0.05);
    } 
    else {
      osc.amp(0, 0.5);
    }

  }


}


class Buttons {

  constructor(xpos, y, diameter) {

    this.isPressed = false;
    this.xpos = xpos;
    this.y = y;
    this.diameter = diameter;


  }

  button() {
    fill(208, 165, 205);
    noStroke();

    let distance = dist(mouseX, mouseY, this.xpos, this.y);

    this.radius = this.diameter / 2;

    if (mouseIsPressed) {
      if (distance < this.radius) {
        fill(193, 75, 136);
        stroke(250, 10, 175);
        strokeWeight(5);
        this.isPressed = true;
      }

    } else {
      this.isPressed = false;
    }

    circle(this.xpos, this.y, this.diameter);
  }

  drawSquare(xpos, y, diameter) {
    // le doy la posicion del boton
    if (this.isPressed) {
      rect(this.xpos, this.y, this.diameter, this.diameter);
    } else {
      this.isPressed = false;
    }
  }
}