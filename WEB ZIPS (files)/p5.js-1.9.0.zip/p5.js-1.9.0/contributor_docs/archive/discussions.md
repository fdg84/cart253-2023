Joining in on the discussion about how p5 is developed is a great way to contribute. This can be done in a number of ways but one great place to start is by checking out the existing Github [issues that have been labeled 'discussion'](https://github.com/processing/p5.js/labels/discussion) and adding your voice.

The documents in this subsection are developed based on these discussion. This is where we compile ideas about current and future design for the library.
