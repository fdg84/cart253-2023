# Benchmarking p5.js

Benchmarking has been moved to its own repo available at https://github.com/limzykenneth/p5-benchmark. A overall view of the benchmark result of the latest version of p5.js can be seen at https://limzykenneth.github.io/p5-benchmark/. This is still a work in progress.