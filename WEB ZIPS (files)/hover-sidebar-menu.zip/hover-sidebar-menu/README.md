# Hover Sidebar Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/schliflo/pen/nEqZry](https://codepen.io/schliflo/pen/nEqZry).

A little menu that shows itself on :hover state.