import * as funkyDownTempo from "./funkyDownTempo";
import * as drone from "./drone";

export default { 1: funkyDownTempo, 2: drone };
