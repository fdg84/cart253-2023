export const almostImmediately = "+0.05";
