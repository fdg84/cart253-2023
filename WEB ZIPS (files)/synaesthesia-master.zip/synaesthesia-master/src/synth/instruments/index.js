import * as bass from "./bass";
import * as pads from "./pads";
import * as drums from "./drums";
import * as lead from "./lead";
import * as presets from "./presets";

export default { bass, pads, drums, lead, presets };
