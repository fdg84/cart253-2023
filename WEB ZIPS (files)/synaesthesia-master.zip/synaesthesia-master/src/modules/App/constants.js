export const MODULE_NAME = "App";
