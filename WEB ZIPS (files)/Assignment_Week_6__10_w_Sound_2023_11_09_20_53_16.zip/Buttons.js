class Buttons {

  constructor(xpos, y, diameter) {

    this.isPressed = false;
    this.xpos = xpos;
    this.y = y;
    this.diameter = diameter;
  }

  button() {
    fill(180,0,100);
    noStroke();

    let distance = dist(mouseX, mouseY, this.xpos, this.y);

    this.radius = this.diameter / 2;

    if (mouseIsPressed) {
      if (distance < this.radius) {
        fill(193, 75, 136);
        stroke(250, 10, 175);
        strokeWeight(5);
        this.isPressed = true; 
      }

    } else {
      this.isPressed = false;
    }

    circle(this.xpos, this.y, this.diameter);
  }

  drawSquare(xpos, y, diameter) {
    // le doy la posicion del boton
    if (this.isPressed) {
      rect(this.xpos, this.y, this.diameter, this.diameter);
    } else {
      this.isPressed = false;
    }
  }
}