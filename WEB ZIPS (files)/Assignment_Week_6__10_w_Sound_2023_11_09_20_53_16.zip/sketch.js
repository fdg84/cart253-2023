// array of buttons
let buttonsArray = [];
let buttonsSound = [];
let frequency = [100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800, 850];


//for loop variables
let sizeButton = 80;
let startingPoint = 50;
let spacing = 100;



function setup() { 
  createCanvas(400, 400);
  rectMode(CENTER);

  // Create an array of buttons objects to fill the screen
  // columns
  for (let columns = startingPoint; columns < height; columns += spacing) {
    // rows
    for (let row = startingPoint; row < width; row += spacing) {
      // parameters: x, y, size
      buttonsArray.push(new Buttons(row, columns, sizeButton));
      
      buttonsSound.push(new p5.Oscillator());   
    }
  }

  for(i=0;i< buttonsSound.length;i++){
    buttonsSound[i].setType('sine');
    buttonsSound[i].amp(0);
    buttonsSound[i].start();
  }
}

function draw() {
  background(220);
  
  for (i = 0 ; i < buttonsArray.length; i++){
       
  //  buttonsArray[i].drawSquare();
    buttonsArray[i].button();

    if (buttonsArray[i].isPressed) {
      buttonsSound[i].freq(frequency[i]);
      buttonsSound[i].amp(0.5, 0.05);
      console.log(i);
    } 
    else {
      buttonsSound[i].amp(0, 0.05);
    }
  }
}